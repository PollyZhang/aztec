javabase64 - A pure Java library for reading and writing Base64
========================================

Instructions
------------
Unzip.

Add the javabase64 JAR to your application CLASSPATH and enjoy it.

Supported platforms: Java 2 version 1.2 or later

Documentation
-------------
Developer quickstart guide in doc/manual-en.html (for Italian manual-it.html)

How to build
------------
See BUILD.txt

License
-------
See LICENSE.txt

Changelog
---------
See CHANGELOG.txt